"use client"

import React, { useState, useEffect } from "react"
import Link from "next/link"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface User {
  id: string
  Age: number
  UserName: string
}

export default function Page() {
  const [users, setUsers] = useState<User[]>([])

  // Fetch users
  useEffect(() => {
    fetch("https://6943a59869b12460f3156f33.mockapi.io/User")
      .then((res) => res.json())
      .then(setUsers)
      .catch(console.error)
  }, [])

  // Delete user
  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this user?")) return

    try {
      await fetch(`https://6943a59869b12460f3156f33.mockapi.io/User/${id}`, {
        method: "DELETE",
      })
      setUsers(users.filter((u) => u.id !== id))
    } catch (err) {
      console.error(err)
      alert("Failed to delete user")
    }
  }

  return (
    <div className="rounded-lg border bg-background">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="w-[80px] text-center">ID</TableHead>
            <TableHead className="w-[100px] text-center">Age</TableHead>
            <TableHead>Username</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          {users.length === 0 ? (
            <TableRow>
              <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                No users found
              </TableCell>
            </TableRow>
          ) : (
            users.map((user) => (
              <TableRow key={user.id} className="hover:bg-muted/50 transition-colors">
                <TableCell className="text-center font-medium">{user.id}</TableCell>
                <TableCell className="text-center">
                  <Badge variant="secondary">{user.Age}</Badge>
                </TableCell>
                <TableCell className="font-medium">{user.UserName}</TableCell>
                <TableCell className="text-right flex justify-end gap-2">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/user/${user.id}`}>View</Link>
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => handleDelete(user.id)}>
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}
