import React from "react";
import Link from "next/link";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const data = await fetch(
    `https://6943a59869b12460f3156f33.mockapi.io/User/${id}`
  );
  const posts = await data.json();

  return (
    <Card className="max-w-2xl">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl font-semibold">
            User Details
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            User ID: <span className="font-medium">{id}</span>
          </p>
        </div>

       
        <Button asChild variant="outline" size="sm">
          <Link href="/user">Go Back</Link>
        </Button>
      </CardHeader>

      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-[100px] text-center">
                ID
              </TableHead>
              <TableHead className="text-center">
                Age
              </TableHead>
              <TableHead>
                Username
              </TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            <TableRow className="hover:bg-muted/50 transition-colors">
              <TableCell className="text-center font-medium">
                {posts.id}
              </TableCell>

              <TableCell className="text-center">
                <Badge variant="secondary">
                  {posts.Age}
                </Badge>
              </TableCell>

              <TableCell className="font-medium">
                {posts.UserName}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
