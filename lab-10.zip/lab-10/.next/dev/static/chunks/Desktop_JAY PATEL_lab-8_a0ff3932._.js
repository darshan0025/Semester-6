(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_98893619._.js",
  "static/chunks/2f3af_next_dist_compiled_react-dom_64f6f57e._.js",
  "static/chunks/2f3af_next_dist_compiled_react-server-dom-turbopack_64a01063._.js",
  "static/chunks/2f3af_next_dist_compiled_next-devtools_index_748b5232.js",
  "static/chunks/2f3af_next_dist_compiled_730e6b4e._.js",
  "static/chunks/2f3af_next_dist_client_89d180d3._.js",
  "static/chunks/2f3af_next_dist_453f5efe._.js",
  "static/chunks/2f3af_@swc_helpers_cjs_3f63fb28._.js"
],
    source: "entry"
});
