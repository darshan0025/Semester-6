(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_JAY PATEL_lab-8_components_ui_table_tsx_8286523c._.js"
],
    source: "dynamic"
});
