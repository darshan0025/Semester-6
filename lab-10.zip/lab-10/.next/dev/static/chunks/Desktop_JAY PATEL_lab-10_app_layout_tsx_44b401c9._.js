(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__7a6d582f._.css",
  "static/chunks/d03e4_98817f0d._.js",
  "static/chunks/Desktop_JAY PATEL_lab-10_4c9ebb49._.js"
],
    source: "dynamic"
});
