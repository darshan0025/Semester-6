(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__3000002b._.css",
  "static/chunks/2f3af_9b7d6686._.js",
  "static/chunks/Desktop_JAY PATEL_lab-8_12187d35._.js"
],
    source: "dynamic"
});
