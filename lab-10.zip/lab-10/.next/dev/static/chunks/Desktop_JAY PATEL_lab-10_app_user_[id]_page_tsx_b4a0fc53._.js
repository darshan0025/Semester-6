(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_JAY PATEL_lab-10_components_ui_table_tsx_df3431c1._.js"
],
    source: "dynamic"
});
