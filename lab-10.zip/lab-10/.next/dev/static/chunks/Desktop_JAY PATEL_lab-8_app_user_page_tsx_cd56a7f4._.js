(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/81719_a4be151d._.js",
  "static/chunks/Desktop_JAY PATEL_lab-8_2eb847f0._.js"
],
    source: "dynamic"
});
