module.exports = [
"[project]/Desktop/JAY PATEL/lab-10/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_JAY%20PATEL_lab-10__next-internal_server_app__not-found_page_actions_cd975c85.js.map