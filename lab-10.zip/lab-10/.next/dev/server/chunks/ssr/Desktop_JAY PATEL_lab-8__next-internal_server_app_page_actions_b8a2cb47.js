module.exports = [
"[project]/Desktop/JAY PATEL/lab-8/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_JAY%20PATEL_lab-8__next-internal_server_app_page_actions_b8a2cb47.js.map