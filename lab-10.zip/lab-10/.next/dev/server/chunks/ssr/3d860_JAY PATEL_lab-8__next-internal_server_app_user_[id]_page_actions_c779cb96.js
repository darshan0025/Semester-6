module.exports = [
"[project]/Desktop/JAY PATEL/lab-8/.next-internal/server/app/user/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_JAY%20PATEL_lab-8__next-internal_server_app_user_%5Bid%5D_page_actions_c779cb96.js.map