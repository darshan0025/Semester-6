module.exports = [
"[project]/Desktop/JAY PATEL/lab-8/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_JAY%20PATEL_lab-8__next-internal_server_app__not-found_page_actions_f4e6c042.js.map