module.exports = [
"[project]/Desktop/JAY PATEL/lab-10/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_JAY%20PATEL_lab-10__next-internal_server_app_page_actions_cb173674.js.map