module.exports = [
"[project]/Desktop/JAY PATEL/lab-10/.next-internal/server/app/user/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_JAY%20PATEL_lab-10__next-internal_server_app_user_%5Bid%5D_page_actions_0b6aa4b5.js.map