globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/d03e4_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_538612a8._.js",
    "static/chunks/d03e4_next_dist_compiled_react-dom_bb882c45._.js",
    "static/chunks/d03e4_next_dist_compiled_react-server-dom-turbopack_d1c086bb._.js",
    "static/chunks/d03e4_next_dist_compiled_next-devtools_index_bd63d87d.js",
    "static/chunks/d03e4_next_dist_compiled_8c1ca763._.js",
    "static/chunks/d03e4_next_dist_client_6f882cbb._.js",
    "static/chunks/d03e4_next_dist_52715d8e._.js",
    "static/chunks/d03e4_@swc_helpers_cjs_84913b28._.js",
    "static/chunks/Desktop_JAY PATEL_lab-10_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_JAY PATEL_lab-10_aefb4073._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];